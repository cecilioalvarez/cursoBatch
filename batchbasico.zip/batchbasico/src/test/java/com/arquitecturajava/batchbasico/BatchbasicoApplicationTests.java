package com.arquitecturajava.batchbasico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchbasicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
